"""Untouched hold-out set: 20 hand-written, hand-labelled answers on 7 new problems.

Written after all parser development was finished and evaluated exactly once; the code was NOT changed
in response to the result, so this measures generalisation to unseen phrasing honestly.
Hand-derived optima:
  N03 (3, 1) Z = 11 (degenerate corner)   N04 (2, 2) Z = 16   N05 (2, 4) Z = 14   N06 unbounded
  N07 infeasible                          N08 multiple, Z = 16 on 2x + y = 8 from (0, 8) to (3, 2)
  N09 (3/5, 6/5) Z = 12/5 (degenerate)"""

P = {
    "N03": "Maximize Z = 3x1 + 2x2 subject to x1 + x2 <= 4, x1 + 3x2 <= 6, x1 <= 3, x1, x2 >= 0",
    "N04": "Minimize Z = 5x + 3y subject to 2x + y >= 6, x + y >= 4, x, y >= 0",
    "N05": "Maximize Z = x + 3y subject to x + 2y <= 10, x <= 4, y <= 4, x, y >= 0",
    "N06": "Maximize Z = 2x + y subject to x - y <= 2, x + y >= 1, x, y >= 0",
    "N07": "Maximize Z = x + y subject to x + y <= 5, 2x + 2y >= 12, x, y >= 0",
    "N08": "Maximize Z = 4x + 2y subject to 2x + y <= 8, x <= 3, x, y >= 0",
    "N09": "Minimize Z = 2x1 + x2 subject to 3x1 + x2 >= 3, 4x1 + 3x2 >= 6, x1 + 2x2 <= 3, x1, x2 >= 0",
}
CASES = [
    ("N03", "x1 = 3, x2 = 1 gives Z = 11 (maximum).", "correct"),
    ("N03", "Max Z = 11 at (3, 1).", "correct"),
    ("N03", "x1 = 3, x2 = 0, Z = 9", "suboptimal_solution"),
    ("N04", "Minimum cost is 16, achieved at x = 2 and y = 2.", "correct"),
    ("N04", "Optimal: x = 0, y = 6, Z = 18.", "suboptimal_solution"),
    ("N04", "x = 2, y = 2, minimum Z = 14.", "wrong_value"),
    ("N05", "The optimal solution: x = 2, y = 4; Z max = 14.", "correct"),
    ("N05", "x = 4, y = 4, Z = 16", "infeasible_solution"),
    ("N05", "Z = 13 at (4, 3) is the maximum.", "suboptimal_solution"),
    ("N06", "The objective increases without limit along x = y + 2, so the LP is unbounded.", "correct"),
    ("N06", "Optimal at x = 2, y = 0 with Z = 4.", "wrong_status"),
    ("N07", "Since x + y cannot be both at most 5 and at least 6, there is no feasible solution.", "correct"),
    ("N07", "x = 5, y = 0 maximises Z = 5.", "wrong_status"),
    ("N08", "Every point on 2x + y = 8 between (0, 8) and (3, 2) is optimal, Z = 16.", "correct"),
    ("N08", "The unique optimum is x = 3, y = 2, Z = 16.", "missed_multiple_optima"),
    ("N08", "x = 0, y = 8, Z = 16", "correct"),
    ("N09", "x1 = 3/5, x2 = 6/5, minimum Z = 12/5.", "correct"),
    ("N09", "x1 = 0.6, x2 = 1.2 and Z = 2.4", "correct"),
    ("N09", "Optimal solution x1 = 3, x2 = 0 with Z = 6.", "suboptimal_solution"),
    ("N09", "x1 = 0.6, x2 = 1.2, Z = 3.0", "wrong_value"),
]
