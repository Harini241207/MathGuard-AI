"""Hand-written, hand-labelled evaluation cases (independent of MathGuard's generator and rules).

Each label was assigned manually from the problem's known solution, using the category definitions:
  correct                 everything stated is right (for multiple optima: any optimal point, not called unique)
  wrong_status            claims infeasible / unbounded / multiple when that is false, or a finite optimum when there is none
  missed_multiple_optima  calls the optimum unique although alternative optima exist
  infeasible_solution     the stated point violates a constraint
  suboptimal_solution     the stated point is feasible but not optimal
  wrong_value             the point (if any) is right but the objective value is wrong
Review log: an independent re-check of the hand computations found two labelling slips (N01: 4*3 + 5*2 = 22,
not 23); the answer texts were corrected so that the labels match the arithmetic.
The styles deliberately differ from backend/datagen.py so the parser is also tested on unseen phrasing."""

P = {
    "G01": "Maximize Z = 3x + 2y subject to x + y <= 4, x <= 2, y <= 3, x, y >= 0",
    "G02": "Minimize Z = 2x + 3y subject to x + y >= 4, x + 2y >= 6, x, y >= 0",
    "G03": "Maximize Z = 2x + 4y subject to x + 2y <= 8, x <= 6, y <= 5, x, y >= 0",
    "G04": "Maximize Z = 3x + 2y subject to x + y <= 2, x + y >= 5, x, y >= 0",
    "G05": "Maximize Z = x + y subject to x - y >= 1, x, y >= 0",
    "G06": "Maximize Z = 5x + 4y subject to x + y <= 6, 2x + y <= 8, x + 2y <= 10, x, y >= 0",
    "G07": "Maximize Z = 4x + 3y subject to x + y <= 8, x <= 5, y <= 6, x + y <= 12, x, y >= 0",
    "G08": "Maximize Z = 6x + 5y subject to 2x + y <= 10, x + 2y <= 8, x <= 4, x, y >= 0",
    "G09": "Minimize Z = 3x + 2y subject to x + y >= 5, 2x + y >= 8, x + 3y >= 9, x, y >= 0",
    "G10": "Maximize Z = 40x + 30y subject to 2x + y <= 100, x + 2y <= 80, x, y >= 0",
    "S01": "Maximize Z = 3x + 5y subject to x + y <= 4, x <= 2, y <= 3, x, y >= 0",
    "S02": "Maximize Z = 5x + 4y + 3z subject to x + y + z <= 8, 2x + y <= 10, y + 2z <= 8, x, y, z >= 0",
    "S03": "Maximize Z = 2x + y subject to x + y <= 2, x <= 1, y <= 1, x, y >= 0",
    "S04": "Maximize Z = 2x + 4y subject to x + 2y <= 8, x + y <= 6, x, y >= 0",
    "S05": "Maximize Z = 3x + 2y subject to x - y <= 1, x, y >= 0",
    "S06": "Maximize Z = 4x + 3y subject to 2x + y <= 8, x + y <= 5, x <= 3, x, y >= 0",
    "S07": "Maximize Z = 6x + 5y subject to x + 2y <= 8, 3x + 2y <= 12, x <= 3, x, y >= 0",
    "S08": "Maximize Z = 4x + 6y subject to x + y <= 5, x + 2y <= 8, x, y >= 0",
    "S09": "Maximize Z = 3x + 2y + 4z subject to x + y + z <= 6, 2x + y <= 8, y + 2z <= 8, x, y, z >= 0",
    "S10": "Maximize Z = 5x + 4y subject to x + y <= 7, 2x + y <= 10, x + 2y <= 11, x, y >= 0",
    "N01": "Minimize Z = 4x1 + 5x2 subject to 2x1 + x2 >= 8, x1 + 3x2 >= 9, x1, x2 >= 0",
    "N02": "Maximize Z = 2x1 + 3x2 subject to x1 + x2 <= 6, x1 + 3x2 <= 12, x1, x2 >= 0",
}

CASES = [
    # ---- correct answers, varied styles
    ("G01", "Plotting the constraints, the vertices are O(0,0), A(2,0), B(2,2), C(1,3), D(0,3).\nZ is largest at B.\n\n**Answer:** Zmax = 10 at x = 2, y = 2", "correct"),
    ("G02", "The minimum of Z = 2x + 3y over the region occurs where x + y = 4 meets x + 2y = 6, i.e. at (2, 2). Hence Z_min = 10.", "correct"),
    ("G03", "The objective 2x + 4y = 2(x + 2y) is parallel to the binding constraint x + 2y = 8, so every point between (0, 4) and (6, 1) is optimal; there are infinitely many optimal solutions with Z = 16.", "correct"),
    ("G04", "x + y cannot be both at most 2 and at least 5. These constraints are inconsistent, so no feasible solution exists.", "correct"),
    ("G05", "Along the ray (1 + t, t) the constraint holds for every t >= 0 and Z = 1 + 2t grows without limit. The LP is unbounded.", "correct"),
    ("G06", "Corner points: (0,0) -> 0, (4,0) -> 20, (2,4) -> 26, (0,5) -> 20.\nOptimal solution: (x, y) = (2, 4) with maximum profit 26.", "correct"),
    ("G07", "Evaluating at the extreme points, the best is x* = 5, y* = 3, giving Z* = 29.", "correct"),
    ("G08", "$$x = 4,\\quad y = 2,\\quad Z_{\\max} = 34$$", "correct"),
    ("G09", "Final result: minimum cost Z = 13 when x = 3 and y = 2.", "correct"),
    ("G10", "Produce 40 units of x and 20 units of y. Maximum profit = Rs 2,200.", "correct"),
    ("S01", "After two iterations all Cj - Zj <= 0.\nOptimal: x = 1, y = 3, Z = 18.", "correct"),
    ("S02", "One optimal solution is x = 5, y = 0, z = 3 with Z = 34 (a non-basic variable has zero net evaluation, so alternative optima exist).", "correct"),
    ("S03", "The simplex method ends at x = 1, y = 1 (degenerate basis), Z = 3.", "correct"),
    ("S04", "Multiple optimal solutions: (0, 4) and (4, 2) both give Z = 16.", "correct"),
    ("S05", "x2 can enter but its column has no positive entry, so the solution is unbounded.", "correct"),
    ("S06", "x = 3, y = 2 and the maximum value of Z is 18.", "correct"),
    ("S07", "Thus the optimal plan is x = 2, y = 3, Z = 27.", "correct"),
    ("S09", "Optimal: (x, y, z) = (2, 0, 4), Z = 22.", "correct"),
    ("S10", "Hence x = 3, y = 4 and Zmax = 31.", "correct"),
    ("N01", "Minimum Z = 22 at x1 = 3, x2 = 2.", "correct"),
    ("N02", "The maximum Z = 15 is attained at x1 = 3, x2 = 3.", "correct"),
    # ---- wrong objective value (point right)
    ("G01", "Optimal point (2, 2). Maximum Z = 12.", "wrong_value"),
    ("G06", "x = 2, y = 4, so Z = 5(2) + 4(4) = 24.", "wrong_value"),
    ("S07", "x = 2, y = 3, Z = 6(2) + 5(3) = 26.", "wrong_value"),
    ("G10", "x = 40, y = 20 giving maximum profit 2000.", "wrong_value"),
    ("S09", "Optimal: x = 2, y = 0, z = 4 and Z = 24.", "wrong_value"),
    ("N01", "x1 = 3, x2 = 2, minimum Z = 23.", "wrong_value"),
    # ---- feasible but not optimal
    ("G01", "The corners are (0,0), (2,0), (2,2), (1,3), (0,3). Choosing (1, 3) we get Z = 9, which is the maximum.", "suboptimal_solution"),
    ("G07", "Best corner: x = 2, y = 6, Z = 26.", "suboptimal_solution"),
    ("S01", "The initial tableau gives x = 0, y = 0. Optimal Z = 0.", "suboptimal_solution"),
    ("G09", "Minimum Z = 16 at x = 0, y = 8.", "suboptimal_solution"),
    ("S06", "x = 3, y = 1, Z = 15.", "suboptimal_solution"),
    ("S10", "Optimal: x = 5, y = 0, Z = 25.", "suboptimal_solution"),
    ("N02", "x1 = 6, x2 = 0 gives the maximum Z = 12.", "suboptimal_solution"),
    # ---- infeasible point
    ("G01", "The optimum is at x = 2, y = 3 where Z = 12.", "infeasible_solution"),
    ("G08", "x = 4, y = 3, Z = 39.", "infeasible_solution"),
    ("S08", "Optimal solution x = 0, y = 5, Z = 30.", "infeasible_solution"),
    ("G02", "Minimum at (1, 2): Z = 8.", "infeasible_solution"),
    ("S07", "x = 3, y = 3, Z = 33.", "infeasible_solution"),
    # ---- wrong status
    ("G05", "The optimal solution is x = 1, y = 0 with Z = 1.", "wrong_status"),
    ("S05", "Final answer: x = 1, y = 0, Z = 3.", "wrong_status"),
    ("G04", "The best feasible point is (2, 0) with Z = 6.", "wrong_status"),
    ("G01", "The feasible region is empty, so the problem is infeasible.", "wrong_status"),
    ("S06", "Z increases without bound, therefore the problem is unbounded.", "wrong_status"),
    ("G09", "Since the region is unbounded, the problem has no finite minimum.", "wrong_status"),
    # ---- missed alternative optima
    ("S04", "The unique optimal solution is x = 0, y = 4 with Z = 16.", "missed_multiple_optima"),
    ("G03", "Optimal solution (unique): x = 6, y = 1, Z = 16.", "missed_multiple_optima"),
    ("S02", "The optimum is unique: x = 2, y = 6, z = 0 and Z = 34.", "missed_multiple_optima"),
    # ---- harder phrasing
    ("S08", "| Variable | Value |\n|---|---|\n| x | 2 |\n| y | 3 |\n\nMaximum Z = 26.", "correct"),
    ("G06", "\\boxed{x = 2,\\ y = 4,\\ Z = 26}", "correct"),
]
