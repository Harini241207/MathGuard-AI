"""Build MathGuard's structured datasets.

Outputs (in data/):
  mathguard_extended_dataset.jsonl  structured problem / answer / error records (original 30 rows preserved)
  independent_eval.jsonl            hand-written, hand-labelled final answers (held out from all training)
  step_examples.json                samples shown in the web app

Labels in the extended dataset come from the generator (the mistake that was deliberately injected), not
from the verifier, so they can be used to evaluate the verifier.  No textbook is quoted: every problem is an
original test problem that follows standard textbook methodology.

Run from the project root:  python -m scripts.build_datasets
"""
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from backend import graphical_solver, simplex_solver, solver  # noqa: E402
from backend.ai_render import GRAPHICAL_MISTAKES, make_answer, make_graphical_answer  # noqa: E402
from backend.lp_parser import parse_problem  # noqa: E402
from backend.step_verifier import verify  # noqa: E402
from scripts.independent_eval_cases import CASES, P  # noqa: E402
from tests import fixtures as F  # noqa: E402

DATA = ROOT / "data"
REF = "Original test problem built on standard textbook methodology (no textbook text is quoted)."

SIMPLEX_MISTAKES = {
    None: [], "entering_not_best": [], "entering_bad": ["E03"], "leaving_bad": ["E04"], "ratio_text": ["E04"],
    "pivot_claim": ["E11"], "normalise_rhs": ["E05"], "rowop_cell": ["E06"], "zj_cell": ["E07"],
    "premature_stop": ["E13"], "wrong_value": ["E12"], "unique_claim": ["E13"],
}
GRAPH_CODES = {None: [], "intercept": ["G01"], "intersection": ["G02"], "infeasible_corner": ["G03"],
               "evaluation": ["G04"], "wrong_pick": ["G05"], "missed_corner": ["G03"]}

SIMPLEX_PROBLEMS = {
    "S01": P["S01"], "S03": P["S03"], "S04": P["S04"], "S06": P["S06"], "S07": P["S07"], "S08": P["S08"], "S09": P["S09"],
    "S10": P["S10"], "S05": P["S05"],
    "X01": "Maximize Z = 5x1 + 4x2 subject to 6x1 + 4x2 <= 24, x1 + 2x2 <= 6, -x1 + x2 <= 1, x2 <= 2, x1, x2 >= 0",
    "X02": "Maximize Z = 2x1 + 3x2 + 4x3 subject to 3x1 + 2x2 + x3 <= 10, 2x1 + 5x2 + 3x3 <= 15, x1, x2, x3 >= 0",
    "X03": "Minimize Z = x1 - 3x2 + 2x3 subject to 3x1 - x2 + 2x3 <= 7, -2x1 + 4x2 <= 12, -4x1 + 3x2 + 8x3 <= 10, x1, x2, x3 >= 0",
}
GRAPH_PROBLEMS = {k: P[k] for k in ("G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10")}


def summary_of(prob):
    t = solver.solve(prob)
    return {"status": t["status"], "solution": t["solution"], "value": t["value"], "optimal_corners": t["face"]}


def first_correction(rep):
    bad = [s for s in rep["steps"] if s["status"] == "incorrect"]
    if not bad:
        return None
    s = bad[0]
    return {"where": f"{s['group']} - {s['title']}", "ai_value": s["ai_value"], "correct_value": s["correct_value"],
            "explanation": s["message"]}


def main():
    rows = []
    # ---- original 30 rows, preserved verbatim
    for line in (DATA / "mathguard_30q_dataset_step2.jsonl").read_text().splitlines():
        r = json.loads(line)
        rows.append({"problem_id": r["id"], "source": "original", "optimization_method": r["method"], "original": r})
    # ---- simplex step-level records
    k = 0
    for pid, q in SIMPLEX_PROBLEMS.items():
        prob = parse_problem(q)
        ref = simplex_solver.solve(prob)
        truth = solver.solve(prob)
        for mistake, codes in SIMPLEX_MISTAKES.items():
            for style in ("md", "latex", "plain"):
                at = 1 if mistake == "entering_bad" else 0
                txt, applied = make_answer(prob, mistake, at_iter=at, seed=k, style=style,
                                           slack_naming="x" if pid.startswith("X") else "s", decimals=pid == "X01")
                k += 1
                if mistake and not applied:
                    continue
                if mistake == "unique_claim" and truth["status"] != "multiple_optima":
                    continue
                rep = verify(prob, "simplex", txt, ref, truth)
                rows.append({
                    "problem_id": f"{pid}-{mistake or 'correct'}-{style}", "source": "generated", "optimization_method": "simplex",
                    "original_problem": q, "correct_solution": summary_of(prob), "step_by_step_solution": ref["explanation"],
                    "ai_generated_answer": txt, "answer_style": style, "injected_mistake": mistake or "none",
                    "error_category": codes, "expected_verdict": "correct" if not codes else "error",
                    "corrected_calculation": first_correction(rep),
                    "verification_status": {"verdict": rep["summary"]["verdict"],
                                            "detected_codes": sorted({s.get("code") for s in rep["steps"] if s["status"] == "incorrect" and s.get("code")})},
                    "reference_source": REF})
    # ---- graphical records
    for pid, q in GRAPH_PROBLEMS.items():
        prob = parse_problem(q)
        g = graphical_solver.solve(prob)
        truth = solver.solve(prob)
        for mistake in [None] + GRAPHICAL_MISTAKES:
            txt, applied = make_graphical_answer(prob, mistake, seed=k)
            k += 1
            if mistake and not applied:
                continue
            rep = verify(prob, "graphical", txt, g, truth)
            rows.append({
                "problem_id": f"{pid}-{mistake or 'correct'}", "source": "generated", "optimization_method": "graphical",
                "original_problem": q, "correct_solution": summary_of(prob), "step_by_step_solution": g["explanation"],
                "ai_generated_answer": txt, "answer_style": "text", "injected_mistake": mistake or "none",
                "error_category": GRAPH_CODES[mistake], "expected_verdict": "correct" if not GRAPH_CODES[mistake] else "error",
                "corrected_calculation": first_correction(rep),
                "verification_status": {"verdict": rep["summary"]["verdict"],
                                        "detected_codes": sorted({s.get("code") for s in rep["steps"] if s["status"] == "incorrect" and s.get("code")})},
                "reference_source": REF})
    with open(DATA / "mathguard_extended_dataset.jsonl", "w") as fh:
        for r in rows:
            fh.write(json.dumps(r, default=str) + "\n")
    print("extended dataset rows:", len(rows))

    # ---- independent hand-labelled set
    with open(DATA / "independent_eval.jsonl", "w") as fh:
        for i, (pid, ans, lab) in enumerate(CASES):
            fh.write(json.dumps({"id": f"IND{i + 1:03d}", "problem_id": pid, "problem": P[pid], "answer": ans, "label": lab,
                                 "label_source": "manual"}) + "\n")
    print("independent eval cases:", len(CASES))

    # ---- web-app samples
    S = []

    def add(label, q, a, method, group, desc, source="Unknown"):
        S.append({"label": label, "question": q, "answer": a, "method": method, "group": group, "description": desc,
                  "source": source, "expected": "correct" if "correct" in desc.lower() and "mistake" not in desc.lower() else "invalid"})
    G = "Step-by-step checks"
    add("Simplex · fully correct working (Markdown tables)", F.S01_Q, F.S01_CORRECT_MD, "simplex", G,
        "Correct: every tableau, ratio, pivot and the final answer are right.", "ChatGPT")
    add("Simplex · row-operation slip in iteration 2", F.S01_Q, F.S01_ROWOP_ERROR, "simplex", G,
        "Contains a mistake: one RHS entry is computed wrongly; the final answer is still right.", "Gemini")
    add("Simplex · valid but non-textbook entering choice", F.S01_Q, F.S01_WRONG_ENTERING, "simplex", G,
        "Correct result via a different valid path (x enters before y).", "Claude")
    add("Simplex · LaTeX array tableaus", F.S01_Q, F.S01_LATEX, "simplex", G, "Correct working written in LaTeX.", "Claude")
    add("Simplex · stops too early (premature termination)", F.S01_Q, F.E08_PREMATURE, "simplex", G,
        "Contains a mistake: declares optimality while a positive Cj - Zj remains.", "Other")
    add("Simplex · misses unboundedness", F.E10_UNBOUNDED_Q, F.E10_FINITE_CLAIM, "simplex", G,
        "Contains a mistake: reports a finite optimum for an unbounded problem.", "ChatGPT")
    add("Simplex · claims a unique optimum (alternative optima exist)", F.E09_Q, F.E09_UNIQUE_CLAIM, "simplex", G,
        "Contains a mistake: misses the alternative optima.", "Gemini")
    add("Simplex · only states entering / leaving variables", F.S01_Q, F.CLAIMS_ONLY, "simplex", G,
        "Incomplete working: no tableaus shown.", "Other")
    prob = parse_problem(SIMPLEX_PROBLEMS["X01"])
    txt, _ = make_answer(prob, "normalise_rhs", seed=5, slack_naming="x", decimals=True)
    add("Simplex · pivot row not normalised (x3..x6 as slacks, decimals)", SIMPLEX_PROBLEMS["X01"], txt, "simplex", G,
        "Contains a mistake: the pivot row's RHS was not divided by the pivot element.", "ChatGPT")
    add("Big M · correct, with symbolic M", F.MIN_GE_Q, F.BIGM_CORRECT, "bigm", G, "Correct Big M working (M kept as a symbol).", "Claude")
    add("Big M · wrong penalty sign", F.MIN_GE_Q, F.BIGM_WRONG_PENALTY, "bigm", G,
        "Contains a mistake: -M used for artificial variables in a minimisation problem.", "Gemini")
    add("Two-Phase · correct (Phase I minimises W)", F.MIN_GE_Q, F.TWO_PHASE_MIN_W, "two_phase", G,
        "Correct two-phase working using the Min W convention.", "ChatGPT")
    add("Graphical · correct corner-point working", F.G01_Q, F.G01_CORRECT, "graphical", G, "Correct graphical solution.", "Claude")
    add("Graphical · wrong intersection and intercept", F.G01_Q, F.G01_WRONG, "graphical", G,
        "Contains mistakes: wrong intercept, wrong intersection, so the wrong corner is chosen.", "Gemini")
    T = "Transportation and assignment"
    tq = "       D1  D2  D3  D4  Supply\nS1     19  30  50  10   7\nS2     70  30  40  60   9\nS3     40   8  70  20  18\nDemand  5   8   7  14"
    add("Transportation · VAM + MODI, correct", tq, "Using Vogel's Approximation Method the initial cost is 779.\n"
        "After one MODI iteration: S1 -> D1 = 5, S1 -> D4 = 2, S2 -> D2 = 2, S2 -> D3 = 7, S3 -> D2 = 6, S3 -> D4 = 12.\n"
        "Minimum total cost = 743.", "transportation", T, "Correct.", "ChatGPT")
    add("Transportation · stops at the VAM solution", tq, "Vogel's Approximation Method gives the initial cost 779.\n"
        "S1 -> D1 = 5, S1 -> D4 = 2, S2 -> D3 = 7, S2 -> D4 = 2, S3 -> D2 = 8, S3 -> D4 = 10.\nThis is optimal, so the minimum total cost = 779.",
        "transportation", T, "Contains a mistake: the VAM solution is not optimal (MODI would improve it).", "Gemini")
    aq = "     M1  M2  M3\nJ1    9  11  14\nJ2    6  15  13\nJ3   12  13   6"
    add("Assignment · Hungarian method, correct", aq, "Row reduction:\n0 2 5\n0 9 7\n6 7 0\nColumn reduction:\n0 0 5\n0 7 7\n6 5 0\n"
        "Assignment: J1 -> M2, J2 -> M1, J3 -> M3. Minimum total cost = 23.", "assignment", T, "Correct.", "Claude")
    add("Assignment · wrong row reduction and assignment", aq, "Row reduction:\n0 2 5\n0 8 7\n6 7 0\n"
        "Assignment: J1 -> M1, J2 -> M2, J3 -> M3. Minimum total cost = 30.", "assignment", T, "Contains mistakes.", "Other")
    (DATA / "step_examples.json").write_text(json.dumps(S, indent=1))
    print("web samples:", len(S))


if __name__ == "__main__":
    main()
