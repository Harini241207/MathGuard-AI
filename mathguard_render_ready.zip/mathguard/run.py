import os

from backend.app import app

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    print(f"MathGuard AI running on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
