"""Production entry point:  gunicorn wsgi:app

Works no matter which directory the server starts in, because the project root is put on
sys.path explicitly (the backend package uses relative imports and must be imported as
`backend.app`, never as a top-level `app`).
"""
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from backend.app import app  # noqa: E402  (gunicorn looks for this name)

__all__ = ["app"]
